package myMath;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.function.Predicate;

import myMath.Monom;
/**
 * This class represents a Polynom with add, multiply functionality, it also should support the following:
 * 1. Riemann's Integral: https://en.wikipedia.org/wiki/Riemann_integral
 * 2. Finding a numerical value between two values (currently support root only f(x)=0).
 * 3. Derivative
 * 
 * @author Boaz
 *
 */
public class Polynom implements Polynom_able{


	public Polynom() {
		ArrayList<Monom> poly=new ArrayList<Monom>();
		
	}

	public Polynom(String s) {
		if(s.length()==0)
			throw  new RuntimeException("Error : polynom cann't be Empty ");
		String s2="";
		s=s.replaceAll("-", "+-");
		String[] sub=s.split("\\+");
		for (int i = 0; i < sub.length; i++) {
			if(sub[i].equals(s2))
				continue;
			Monom m=new Monom(sub[i]);
			System.out.println(sub[i]);
			poly.add(m);
			Collections.sort(poly,new Monom_Comperator());
		}



	}

	public Polynom(Monom m) {
		if(poly.isEmpty()) {
			ArrayList<Monom> p=new ArrayList<Monom>();
			p.add(m);
		} else
			poly.add(m);
		Collections.sort(poly,new Monom_Comperator());

	}

	@Override
	public double f(double x) {
		Monom[] a=new Monom[poly.size()];
		poly.toArray(a);
		double result=0;
		for (int i = 0; i < a.length; i++) {
			result=result+a[i].f(x);

		}
		return result;

	}

	@Override
	public void add(Polynom_able p1) {
		Iterator<Monom> it=p1.iteretor();
		while(it.hasNext()) {
			Monom m=it.next();
			poly.add(m);
		}

		Collections.sort(poly,new Monom_Comperator());
		for (int i = 0; i < poly.size()-1; i++) {
			for (int j = poly.size()-1; j>0; j--) {
				if(poly.get(i).get_power()==poly.get(j).get_power()) {
					if(i==j)
						continue;
					poly.set(i, poly.get(i)).set_coefficient(poly.get(i).get_coefficient()+poly.get(j).get_coefficient());
					poly.remove(j);

				}
			}

		}


	}






	@Override
	public void add(Monom m1) {
		Iterator<Monom> it=poly.iterator();
		boolean flag=false;
		while(it.hasNext()) {
			Monom m0=it.next();
			if(m1.get_power()==m0.get_power()) {
				double newco=m0.get_coefficient()+m1.get_coefficient();
				m0.set_coefficient(newco);
				flag=true;
			}
			
		}
		if(flag==false)
			poly.add(m1);
	
		poly.sort(new Monom_Comperator());
		
	}



	@Override
	public void substract(Polynom_able p1) {
		Iterator<Monom> p1it=p1.iteretor();
		while(p1it.hasNext())
			poly.add(p1it.next());
		poly.sort( new Monom_Comperator());
		for (int i = 0; i < poly.size()-1; i++) {
			for (int j = poly.size()-1; j>0; j--) {
				if(poly.get(i).get_power()==poly.get(j).get_power()) {
					if(i==j)
						continue;
					poly.set(i, poly.get(i)).set_coefficient(poly.get(i).get_coefficient()+poly.get(j).get_coefficient());
					poly.remove(j);

				}
			}

		}


	}








	@Override
	public void multiply(Polynom_able p1) {
		Iterator<Monom> it=p1.iteretor();
		Polynom p2=new Polynom();
		Iterator<Monom> it2=this.iteretor();
		while(it2.hasNext()) {
			Monom m=it2.next();
			while(it.hasNext()) {
				Monom m2=it.next();
				p2.add(m.multiply(m2));
				
				
			}
			
		}
		this.poly=p2.poly;


	}




	@Override
	public boolean equals(Polynom_able p1) {
		poly.sort(new Monom_Comperator());
		Polynom p=new Polynom();
		p.poly=this.poly;
		p.substract(p1);
		if(p.poly.isEmpty())
			return false;
		
		return true;
	}
		

	@Override
	public boolean isZero() {
		Polynom p=new Polynom();
		p.poly=this.poly;
		if(poly.isEmpty())
			return true;
		return false;
		
		
	}

	
	
	@Override
	public double root(double x0, double x1, double eps) {
		Polynom p=new Polynom();
		p.poly=this.poly;
		double xleft=x0;
		double xright=x1;
		double xmid=(xright-xleft)/2;
		while(xmid>eps) {
			if(p.f(xmid)*p.f(xleft)<0) {
				xmid=(xmid+xleft)/2;
			}
			if(p.f(xmid)*p.f(xright)<0) {
				xmid=(xmid+xright)/2;
			}
			
			
			
			
		}
		return xmid;
		

		}
		
		

	@Override
	public Polynom_able copy() {
		Polynom_able p=new Polynom();
		Iterator<Monom> it=this.iteretor();
		while(it.hasNext()){
			Monom m=it.next();
			p.add(m);
		}
		return p;
		
	}

	@Override
	public Polynom_able derivative() {
		Polynom_able p=new Polynom();
		Iterator<Monom> it=this.iteretor();
		while(it.hasNext()) {
			Monom m=it.next();
			m.Derivative();
			p.add(m);
			
		}
		return p;
		
		
	}

	@Override
	public double area(double x0, double x1, double eps) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public Iterator<Monom> iteretor() {
		return poly.iterator();
	}

	// ********** add your code below ***********
	private   ArrayList<Monom> poly=new ArrayList<Monom>();

	public String toString() {
		String str="";

		for (int i = 0; i < poly.size(); i++) {
			System.out.print(poly.get(i)+"+");
		}
		System.out.println();


		//System.out.print(p.get(p.size()));
		return str;

	}



}
